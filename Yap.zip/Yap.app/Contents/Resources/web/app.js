/* Yap web UI logic — shared by settings.html, onboarding.html, panel.html.
   Talks to Python (yap.py) through the WKWebView "yap" message handler. */

function send(action, payload) {
  try {
    window.webkit.messageHandlers.yap.postMessage(JSON.stringify({ action: action, payload: payload }));
  } catch (e) { /* running outside the app (e.g. a browser preview) */ }
}

var HOTKEYS = [
  { v: "left",  label: "⌥ + ←" },
  { v: "up",    label: "⌥ + ↑" },
  { v: "right", label: "⌥ + →" },
  { v: "down",  label: "⌥ + ↓" }
];
// Text modes (e.g. Rewrite) fire on Right Command + Right Option + arrow — the
// voice gesture ("Right Option + arrow") plus Command. Same arrows as voice,
// shown with a ⌘⌥ prefix. Command is what makes it rewrite instead of record.
var TEXT_HOTKEYS = [
  { v: "left",  label: "⌘⌥ + ←" },
  { v: "up",    label: "⌘⌥ + ↑" },
  { v: "right", label: "⌘⌥ + →" },
  { v: "down",  label: "⌘⌥ + ↓" }
];
var DEFAULT_REWRITE_PROMPT =
  "Rewrite the following text in a clean, clear and friendly way. Keep my " +
  "meaning and key points. Return only the rewritten text, with no preamble " +
  "or commentary. Do not use em dashes; use commas, colons, or separate " +
  "sentences instead.";
// Audio-capable models per provider (voice is a single native call). The
// free-text box in Settings lets you type any other model id.
var PROVIDER_MODELS = {
  gemini: ["gemini-3.1-flash-lite", "gemini-3.5-flash", "gemini-3.1-pro",
           "gemini-2.5-flash", "gemini-2.5-pro"],
  openai: ["gpt-4o-audio-preview", "gpt-4o-mini-audio-preview"]
};
var PROVIDER_DEFAULT_MODEL = { gemini: "gemini-3.1-flash-lite", openai: "gpt-4o-audio-preview" };
// Models flagged "(Recommended)" in the picker (the dropdown label only — the
// stored value is always the bare model id).
var RECOMMENDED_MODEL = { gemini: "gemini-3.1-flash-lite" };
function modelLabel(provider, id) {
  return id + (RECOMMENDED_MODEL[provider] === id ? "  (Recommended)" : "");
}
var MODE_EMOJI = ["🧹", "📝", "🎙️", "🌍", "✨", "💬", "📌", "⚡"];

var CONFIG = { provider: "gemini",
  providers: {
    gemini: { api_key: "", model: "gemini-3.1-flash-lite" },
    openai: { api_key: "", model: "gpt-4o-audio-preview" }
  },
  trigger_mode: "hold", recording_indicator: "full",
  input_device: "", input_devices: [], modes: [] };

// Make sure CONFIG always has the per-provider shape, folding in any old flat
// api_key/model (belt-and-suspenders; the backend already migrates the file).
function normalizeConfig() {
  if (!CONFIG.providers) CONFIG.providers = {};
  ["gemini", "openai"].forEach(function (p) {
    if (!CONFIG.providers[p]) CONFIG.providers[p] = {};
    if (typeof CONFIG.providers[p].api_key !== "string") CONFIG.providers[p].api_key = "";
    if (!CONFIG.providers[p].model) CONFIG.providers[p].model = PROVIDER_DEFAULT_MODEL[p];
  });
  if (CONFIG.api_key || CONFIG.model) {  // legacy flat fields → gemini slot
    if (CONFIG.api_key && !CONFIG.providers.gemini.api_key) CONFIG.providers.gemini.api_key = CONFIG.api_key;
    if (CONFIG.model) CONFIG.providers.gemini.model = CONFIG.model;
    delete CONFIG.api_key; delete CONFIG.model;
  }
  if (CONFIG.provider !== "gemini" && CONFIG.provider !== "openai") CONFIG.provider = "gemini";
}

/* =========================== SETTINGS =============================== */

function isSettings() { return !!document.getElementById("modes"); }

function el(tag, cls, html) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
}

function hotkeySelect(value) {
  var s = el("select", "hk-select");
  HOTKEYS.forEach(function (h) {
    var o = el("option"); o.value = h.v; o.textContent = h.label;
    if (h.v === value) o.selected = true;
    s.appendChild(o);
  });
  return s;
}

function textHotkeySelect(value) {
  // Arrow picker for text modes (Right ⌘ + Right ⌥ + arrow).
  var s = el("select", "hk-select");
  TEXT_HOTKEYS.forEach(function (h) {
    var o = el("option"); o.value = h.v; o.textContent = h.label;
    if (h.v === value) o.selected = true;
    s.appendChild(o);
  });
  return s;
}

// Look up a shipped default mode by its stable key (sent by Python in
// CONFIG.default_modes). Returns null for user-added modes (no key).
function defaultModeByKey(key) {
  var list = (CONFIG && CONFIG.default_modes) || [];
  for (var i = 0; i < list.length; i++) {
    if (list[i].key === key) return list[i];
  }
  return null;
}

function renderModes() {
  var wrap = document.getElementById("modes");
  wrap.innerHTML = "";
  CONFIG.modes.forEach(function (m, i) {
    var isText = (m.input === "text");
    var pink = /sum/i.test(m.name || "");
    var card = el("div", "mode-card" + (pink ? " pink" : "") + (isText ? " text-mode" : ""));

    var head = el("div", "mode-head");
    var icon = el("div", "mode-icon", isText ? "✍️" : MODE_EMOJI[i % MODE_EMOJI.length]);
    var meta = el("div", "mode-meta");
    var name = el("input", "mode-name"); name.value = m.name || ""; name.placeholder = "Button name";
    name.addEventListener("input", function () { m.name = name.value; });
    var sub = el("div", "mode-sub", isText ? "Text mode · select, then ⌘⌥ + arrow" : "Voice mode");
    meta.appendChild(name); meta.appendChild(sub);

    var kbd = el("div", "kbd-row");
    var hk = isText ? textHotkeySelect(m.hotkey) : hotkeySelect(m.hotkey);
    hk.addEventListener("change", function () { m.hotkey = hk.value; });
    kbd.appendChild(hk);

    head.appendChild(icon); head.appendChild(meta); head.appendChild(kbd);

    var pwrap = el("div", "prompt-wrap");
    pwrap.appendChild(el("label", "prompt-eyebrow", "Prompt"));
    var ta = el("textarea", "prompt"); ta.value = m.prompt || "";
    ta.addEventListener("input", function () { m.prompt = ta.value; });
    pwrap.appendChild(ta);

    var foot = el("div", "mode-card-foot");
    // For a shipped default mode, offer a one-click restore of its name+prompt
    // (other modes and edits are untouched). User-added modes have no key.
    var def = m.key ? defaultModeByKey(m.key) : null;
    if (def) {
      var reset = el("button", "btn-reset", "Reset to default");
      reset.title = "Restore this button’s name and prompt to the shipped default";
      reset.addEventListener("click", function () {
        m.name = def.name; m.prompt = def.prompt; renderModes();
      });
      foot.appendChild(reset);
    }
    var rm = el("button", "btn-remove", "Remove");
    rm.addEventListener("click", function () {
      CONFIG.modes.splice(i, 1); renderModes();
    });
    foot.appendChild(rm);

    card.appendChild(head); card.appendChild(pwrap); card.appendChild(foot);
    wrap.appendChild(card);
  });
}

function maskedKey(v) {  // hide the "PASTE_YOUR…" placeholder; show real keys
  return (v && v.indexOf("PASTE_YOUR") === 0) ? "" : (v || "");
}

// Fill the model dropdown with the given provider's audio-capable models. A
// stored model that isn't one of them goes into the free-text box instead.
function fillModelSelect(provider) {
  var stored = (CONFIG.providers[provider] || {}).model || "";
  var list = PROVIDER_MODELS[provider] || [];
  var inList = list.indexOf(stored) !== -1;
  var sel = document.getElementById("model");
  sel.innerHTML = "";
  sel.setAttribute("data-provider", provider);
  list.forEach(function (mo) {
    var o = el("option"); o.value = mo; o.textContent = modelLabel(provider, mo);
    if (inList && mo === stored) o.selected = true;
    sel.appendChild(o);
  });
  var custom = document.getElementById("model-custom");
  if (custom) custom.value = inList ? "" : stored;
}

function fillVoice() {
  var prov = (CONFIG.provider === "openai") ? "openai" : "gemini";
  var ps = document.getElementById("provider");
  if (ps) ps.value = prov;
  document.getElementById("api-gemini").value = maskedKey(CONFIG.providers.gemini.api_key);
  document.getElementById("api-openai").value = maskedKey(CONFIG.providers.openai.api_key);
  fillModelSelect(prov);
}

function fillRecording() {
  var d = document.getElementById("input-device");
  if (d) {
    var devices = CONFIG.input_devices || [];
    var saved = CONFIG.input_device || "";
    // If the saved mic isn't in the current list (unplugged), keep it as an
    // option labelled "(not connected)" so the user can see what was chosen.
    var hasSaved = devices.some(function (o) { return o.name === saved; });
    d.innerHTML = "";
    devices.forEach(function (o) {
      var opt = el("option"); opt.value = o.name; opt.textContent = o.label;
      d.appendChild(opt);
    });
    if (saved && !hasSaved) {
      var opt = el("option"); opt.value = saved;
      opt.textContent = saved + " (not connected)";
      d.appendChild(opt);
    }
    d.value = saved;
  }
  var t = document.getElementById("trigger-mode");
  if (t) t.value = (CONFIG.trigger_mode === "toggle") ? "toggle" : "hold";
  var r = document.getElementById("recording-indicator");
  if (r) r.value = (CONFIG.recording_indicator === "minimal") ? "minimal" : "full";
}

function banner(msg) {
  var b = document.getElementById("banner");
  if (!b) return;
  if (!msg) { b.classList.remove("show"); return; }
  b.textContent = msg; b.classList.add("show");
}

function collectAndValidate() {
  // pull provider, both keys, and the selected model from the provider pane
  var ps = document.getElementById("provider");
  var prov = (ps && ps.value === "openai") ? "openai" : "gemini";
  CONFIG.provider = prov;
  CONFIG.providers.gemini.api_key = document.getElementById("api-gemini").value.trim();
  CONFIG.providers.openai.api_key = document.getElementById("api-openai").value.trim();
  var custom = (document.getElementById("model-custom").value || "").trim();
  CONFIG.providers[prov].model =
    custom || document.getElementById("model").value || PROVIDER_DEFAULT_MODEL[prov];
  // pull the recording-behavior settings (null-guarded — same form)
  var d = document.getElementById("input-device");
  if (d) CONFIG.input_device = d.value || "";
  var t = document.getElementById("trigger-mode");
  if (t) CONFIG.trigger_mode = (t.value === "toggle") ? "toggle" : "hold";
  var r = document.getElementById("recording-indicator");
  if (r) CONFIG.recording_indicator = (r.value === "minimal") ? "minimal" : "full";
  if (!CONFIG.modes.length) { banner("Add at least one button."); return null; }
  var used = {};
  for (var i = 0; i < CONFIG.modes.length; i++) {
    var m = CONFIG.modes[i];
    if (!m.name || !m.name.trim()) m.name = "Button";
    var isText = (m.input === "text");
    // Voice (arrows) and text (letters) are separate namespaces, so a key only
    // clashes with another button of the same type.
    var key = (isText ? "text:" : "audio:") + m.hotkey;
    if (used[key]) {
      var list = isText ? TEXT_HOTKEYS : HOTKEYS;
      var lbl = list.filter(function (h) { return h.v === m.hotkey; })[0];
      banner("Two " + (isText ? "text" : "voice") + " buttons use " +
        (lbl ? lbl.label : m.hotkey) + ". Each shortcut can only be used once.");
      return null;
    }
    used[key] = true;
  }
  banner("");
  return CONFIG;
}

function doSave(flashId) {
  var cfg = collectAndValidate();
  if (!cfg) return;
  send("save", cfg);
  var f = document.getElementById(flashId);
  if (f) { f.classList.add("show"); setTimeout(function () { f.classList.remove("show"); }, 1800); }
}

/* Python calls these: */
window.yapInit = function (cfg) {
  CONFIG = cfg || CONFIG;
  if (!CONFIG.modes) CONFIG.modes = [];
  normalizeConfig();
  if (isSettings()) {
    renderModes(); fillVoice(); fillRecording(); fillDiagnostics(); fillVersion();
  }
};

// The sidebar and About pane both show the version; yap.py's APP_VERSION is the
// only place it's written. The markup carries the same value as a fallback, so
// the page still reads correctly if this push never lands.
function fillVersion() {
  if (CONFIG.version) {
    document.querySelectorAll("[data-app-version]").forEach(function (n) {
      n.textContent = CONFIG.version;
    });
  }
  if (CONFIG.codename) {
    document.querySelectorAll("[data-app-codename]").forEach(function (n) {
      n.textContent = CONFIG.codename;
    });
  }
}
window.yapSaved = function (ok, msg) { if (!ok && msg) banner(msg); };

// Switch the Settings window to one pane by name ("voice", "diagnostics", …),
// keeping the sidebar selection in step.
function showPane(name) {
  var pane = document.getElementById("pane-" + name);
  if (!pane) return;
  document.querySelectorAll(".nav-item").forEach(function (n) {
    n.classList.toggle("active", n.dataset.pane === name);
  });
  document.querySelectorAll(".pane").forEach(function (p) { p.classList.remove("active"); });
  pane.classList.add("active");
}

function initSettings() {
  // nav
  document.querySelectorAll(".nav-item").forEach(function (item) {
    item.addEventListener("click", function () { showPane(item.dataset.pane); });
  });
  document.getElementById("add-mode").addEventListener("click", function () {
    var freeHk = (HOTKEYS.filter(function (h) {
      return !CONFIG.modes.some(function (m) { return m.input !== "text" && m.hotkey === h.v; });
    })[0] || HOTKEYS[0]).v;
    CONFIG.modes.push({ name: "New button", input: "audio", hotkey: freeHk, prompt: "" });
    renderModes();
  });
  var addText = document.getElementById("add-text-mode");
  if (addText) addText.addEventListener("click", function () {
    var freeHk = (TEXT_HOTKEYS.filter(function (h) {
      return !CONFIG.modes.some(function (m) { return m.input === "text" && m.hotkey === h.v; });
    })[0] || TEXT_HOTKEYS[0]).v;
    CONFIG.modes.push({ name: "Rewrite", input: "text", hotkey: freeHk, prompt: DEFAULT_REWRITE_PROMPT });
    renderModes();
  });
  document.getElementById("save").addEventListener("click", function () { doSave("saved"); });
  document.getElementById("save2").addEventListener("click", function () { doSave("saved2"); });
  var save3 = document.getElementById("save3");
  if (save3) save3.addEventListener("click", function () { doSave("saved3"); });
  // When the provider changes, remember the model showing for the old provider,
  // then repopulate the model list for the newly-selected one.
  var prov = document.getElementById("provider");
  if (prov) prov.addEventListener("change", function () {
    var sel = document.getElementById("model");
    var old = sel.getAttribute("data-provider");
    if (old && CONFIG.providers[old]) {
      var custom = (document.getElementById("model-custom").value || "").trim();
      CONFIG.providers[old].model = custom || sel.value || PROVIDER_DEFAULT_MODEL[old];
    }
    fillModelSelect(prov.value === "openai" ? "openai" : "gemini");
  });
  // Each eye button toggles the visibility of its own key field (data-eye=id).
  document.querySelectorAll(".eye").forEach(function (eye) {
    eye.addEventListener("click", function () {
      var f = document.getElementById(eye.getAttribute("data-eye"));
      if (f) f.type = (f.type === "password") ? "text" : "password";
    });
  });
  wireDiagnostics();
  wireRelaunch();
  send("ready");
}

// Quit & Reopen — Input Monitoring only registers after a relaunch. Present in
// onboarding and in the hotkey test's fix panel.
function wireRelaunch() {
  document.querySelectorAll("[data-relaunch]").forEach(function (b) {
    b.addEventListener("click", function () { send("relaunchApp"); });
  });
}

/* ========================= TEST & DIAGNOSTICS ======================= */

// Each test is independent: click → ask Python to run it → Python pushes back
// progress/result via window.yapDiag. Buttons disable themselves while running so
// a test can't be double-started.
function diagStart(test, btnId, statusId, running) {
  var btn = document.getElementById(btnId);
  var st = document.getElementById(statusId);
  if (btn) btn.disabled = true;
  if (st) { st.className = "diag-status run"; st.textContent = running; }
  if (test === "mic") {
    var m = document.getElementById("diag-mic-meter");
    if (m) m.style.width = "0%";
  }
  send("diag_" + test);
}

function wireDiagnostics() {
  var mic = document.getElementById("diag-mic-btn");
  if (mic) mic.addEventListener("click", function () {
    diagStart("mic", "diag-mic-btn", "diag-mic-status", "Listening… speak now (about 3 seconds).");
  });
  var hk = document.getElementById("diag-hotkey-btn");
  if (hk) hk.addEventListener("click", function () {
    diagStart("hotkey", "diag-hotkey-btn", "diag-hotkey-status",
      "Now hold Right Option (⌥) and tap a voice-button arrow…");
  });
  var paste = document.getElementById("diag-paste-btn");
  if (paste) paste.addEventListener("click", function () {
    diagStart("paste", "diag-paste-btn", "diag-paste-status", "Checking Accessibility…");
  });
  var api = document.getElementById("diag-api-btn");
  if (api) api.addEventListener("click", function () {
    diagStart("api", "diag-api-btn", "diag-api-status", "Contacting the provider…");
  });
  wireFixPanels();
}

// The "Not working?" disclosure under each test: it opens System Settings at the
// exact privacy pane, jumps to another Settings pane, or restarts Yap. Opening a
// panel re-reads the permission so its chip shows the state as it is right now.
function wireFixPanels() {
  document.querySelectorAll("[data-open-pane]").forEach(function (b) {
    b.addEventListener("click", function () {
      send("openPermissionPane", { which: b.getAttribute("data-open-pane") });
    });
  });
  document.querySelectorAll("[data-goto-pane]").forEach(function (b) {
    b.addEventListener("click", function () { showPane(b.getAttribute("data-goto-pane")); });
  });
  document.querySelectorAll(".diag-fix").forEach(function (d) {
    d.addEventListener("toggle", function () { if (d.open) send("permStatus"); });
  });
  send("permStatus");
}

// Reveal the fix panel for a test — used when that test fails, so the answer is
// already open in front of the user instead of hidden behind a click.
function openFixPanel(test) {
  var d = document.querySelector('.diag-fix[data-fix="' + test + '"]');
  if (d && !d.open) d.open = true;
}

// Show the currently-selected microphone name on the mic test card.
function fillDiagnostics() {
  var d = document.getElementById("diag-mic-device");
  if (d) d.textContent = CONFIG.input_device || "Default (system)";
}

// Python → JS bridge for diagnostics results (see _diag_push / _run_diag).
window.yapDiag = function (o) {
  if (!o || !o.test) return;
  if (o.test === "mic" && o.phase === "level") {
    var m = document.getElementById("diag-mic-meter");
    if (m) m.style.width = Math.min(100, Math.round((o.level || 0) * 140)) + "%";
    return;
  }
  if (o.phase !== "done") return;
  var ids = { mic: ["diag-mic-btn", "diag-mic-status"],
              hotkey: ["diag-hotkey-btn", "diag-hotkey-status"],
              paste: ["diag-paste-btn", "diag-paste-status"],
              api: ["diag-api-btn", "diag-api-status"] };
  var pair = ids[o.test]; if (!pair) return;
  var btn = document.getElementById(pair[0]);
  var st = document.getElementById(pair[1]);
  if (btn) btn.disabled = false;
  if (st) {
    st.className = "diag-status " + (o.ok ? "pass" : "fail");
    st.innerHTML = "<span class='diag-badge'>" + (o.ok ? "✓ Pass" : "✗ Fail") +
      "</span> — " + escapeHtml(o.msg || "");
  }
  // A failure is exactly when the how-to-fix steps are worth reading.
  if (!o.ok) { openFixPanel(o.test); send("permStatus"); }
  if (o.test === "mic") {
    var meter = document.getElementById("diag-mic-meter");
    if (meter) meter.style.width = Math.min(100, Math.round((o.level || 0) * 140)) + "%";
  }
};

/* =========================== ONBOARDING ============================= */

function initOnboarding() {
  var steps = Array.prototype.slice.call(document.querySelectorAll(".step"));
  var idx = 0;
  function paintDots() {
    // Every step carries its own .dots strip; keep them all in sync.
    document.querySelectorAll(".dots").forEach(function (wrap) {
      wrap.innerHTML = "";
      steps.forEach(function (_, i) {
        wrap.appendChild(el("span", "dot" + (i === idx ? " on" : "")));
      });
    });
  }
  var permRequested = false;
  function show(i) {
    idx = Math.max(0, Math.min(steps.length - 1, i));
    steps.forEach(function (s, k) { s.classList.toggle("active", k === idx); });
    paintDots();
    // The first time the user lands on the permissions step, ask Python to
    // report status and walk through whatever prompts are still needed.
    if (!permRequested && steps[idx] && steps[idx].querySelector("#perm-list")) {
      permRequested = true;
      send("permReady");
    }
  }

  // ----- API-key step: provider / model selects -----
  var provSel = document.getElementById("onb-provider");
  var modelSel = document.getElementById("onb-model");
  function fillOnbModels(provider) {
    var list = PROVIDER_MODELS[provider] || [];
    modelSel.innerHTML = "";
    list.forEach(function (mo) {
      var o = el("option"); o.value = mo; o.textContent = modelLabel(provider, mo); modelSel.appendChild(o);
    });
    modelSel.value = PROVIDER_DEFAULT_MODEL[provider] || list[0] || "";
  }
  if (provSel && modelSel) {
    fillOnbModels(provSel.value);
    provSel.addEventListener("change", function () { fillOnbModels(provSel.value); });
  }

  document.querySelectorAll("[data-next]").forEach(function (b) {
    b.addEventListener("click", function () { show(idx + 1); });
  });
  document.querySelectorAll("[data-back]").forEach(function (b) {
    b.addEventListener("click", function () { show(idx - 1); });
  });
  document.querySelectorAll("[data-finish]").forEach(function (b) {
    b.addEventListener("click", function () { send("finishOnboarding"); });
  });
  document.querySelectorAll("[data-settings]").forEach(function (b) {
    b.addEventListener("click", function () { send("openSettings"); });
  });
  document.querySelectorAll("[data-getkey]").forEach(function (b) {
    b.addEventListener("click", function (e) { e.preventDefault(); send("getApiKey"); });
  });
  // Eye toggles reveal/hide the key field.
  document.querySelectorAll(".eye").forEach(function (eye) {
    eye.addEventListener("click", function () {
      var f = document.getElementById(eye.getAttribute("data-eye"));
      if (f) f.type = (f.type === "password") ? "text" : "password";
    });
  });
  // "Continue" on the key step: require a key, store it, then advance.
  var keyNext = document.getElementById("onb-key-next");
  if (keyNext) keyNext.addEventListener("click", function () {
    var keyField = document.getElementById("onb-key");
    var err = document.getElementById("onb-key-error");
    var key = (keyField.value || "").trim();
    if (!key) { if (err) err.hidden = false; keyField.focus(); return; }
    if (err) err.hidden = true;
    send("saveOnboardingKey", {
      provider: provSel ? provSel.value : "gemini",
      model: modelSel ? modelSel.value : "",
      api_key: key
    });
    show(idx + 1);
  });
  // Permissions step: each "Open Settings" opens the EXACT privacy pane.
  document.querySelectorAll("[data-pane]").forEach(function (b) {
    var row = b.closest(".perm-row");
    b.addEventListener("click", function () {
      send("openPermissionPane", { which: row.getAttribute("data-perm") });
    });
  });
  wireRelaunch();
  show(0);
}

// Python pushes the latest permission status here — from _perm_tick during
// onboarding, and in reply to "permStatus" from the diagnostics fix panels.
window.yapPerms = function (state) {
  state = state || {};
  // Diagnostics: the chip on each "Not working?" summary.
  document.querySelectorAll(".diag-fix[data-perm]").forEach(function (d) {
    var chip = d.querySelector("[data-perm-chip]");
    if (!chip) return;
    var st = state[d.getAttribute("data-perm")] || "unknown";
    chip.dataset.state = st;
    chip.textContent = st === "granted" ? "✓ Allowed"
      : st === "denied" ? "Not allowed" : "Unknown";
  });
  document.querySelectorAll(".perm-row").forEach(function (row) {
    var which = row.getAttribute("data-perm");
    var st = state[which] || "unknown";
    var pill = row.querySelector("[data-pill]");
    var fix = row.querySelector("[data-pane]");  // exact-pane "Open Settings"
    row.dataset.status = st;
    if (pill) {
      pill.textContent = st === "granted" ? "✓ Granted"
        : st === "denied" ? "Needs access" : "Waiting…";
    }
    // Hide the Settings shortcut once the permission is granted.
    if (fix) fix.hidden = (st === "granted");
  });
};

/* =========================== QUICK PANEL ============================ */

function initPanel() {
  document.querySelectorAll("[data-settings]").forEach(function (b) {
    b.addEventListener("click", function () { send("openSettings"); });
  });
  document.querySelectorAll("[data-copy]").forEach(function (b) {
    b.addEventListener("click", function () { send("copyLast"); });
  });
  document.querySelectorAll("[data-quit]").forEach(function (b) {
    b.addEventListener("click", function () { send("quit"); });
  });
  send("ready");
}
window.yapPanel = function (state) {
  // state: { mode:'idle'|'recording'|'working'|'done', modes:[...], lastYap:'',
  //          compact:bool, trigger:'hold'|'toggle' }
  var live = document.getElementById("live");
  var wave = document.getElementById("wave");
  var status = document.getElementById("status-text");
  var hint = document.getElementById("status-hint");
  var last = document.getElementById("last-yap");
  if (!live) return;
  // Minimal "Listening…" chip vs. the full panel (CSS hides the chrome).
  document.body.classList.toggle("minimal", !!state.compact);
  var m = state.mode || "idle";
  live.dataset.mode = m;
  if (status) {
    status.textContent = m === "recording" ? "Listening…"
      : m === "working" ? "Working on it…"
      : m === "done" ? "Pasted ✓" : "Ready to yap";
  }
  if (hint) {
    var stopHint = (state.trigger === "toggle")
      ? "Tap Right Option to stop" : "Release Right Option when you’re done";
    hint.textContent = m === "recording" ? stopHint
      : m === "working" ? "Sending to Gemini" : "Hold ⌥ and tap an arrow";
  }
  if (wave) wave.classList.toggle("animate", m === "recording" || m === "working");
  if (state.modes && document.getElementById("rows")) renderPanelRows(state.modes);
  if (last && typeof state.lastYap === "string") {
    if (state.lastYap) {
      last.style.display = "block";
      document.getElementById("last-text").textContent = state.lastYap;
    } else { last.style.display = "none"; }
  }
};

function renderPanelRows(modes) {
  var wrap = document.getElementById("rows");
  wrap.innerHTML = "";
  modes.forEach(function (m, i) {
    var isText = (m.input === "text");
    var keyLabel, sub, icon;
    if (isText) {
      var th = TEXT_HOTKEYS.filter(function (h) { return h.v === m.hotkey; })[0];
      keyLabel = th ? th.label : ("⌘⌥ + " + String(m.hotkey || ""));
      sub = "Select text, then ⌘⌥ + arrow";
      icon = "✍️";
    } else {
      var hk = HOTKEYS.filter(function (h) { return h.v === m.hotkey; })[0];
      keyLabel = hk ? hk.label : m.hotkey;
      sub = "Hold ⌥, tap the key";
      icon = MODE_EMOJI[i % MODE_EMOJI.length];
    }
    var pink = /sum/i.test(m.name || "");
    var row = el("div", "prow");
    row.innerHTML =
      '<div class="prow-icon' + (pink ? " pink" : "") + '">' + icon + '</div>' +
      '<div class="prow-meta"><div class="prow-title">' + escapeHtml(m.name || "Button") + '</div>' +
      '<div class="prow-sub">' + sub + '</div></div>' +
      '<div class="prow-key">' + escapeHtml(keyLabel) + '</div>';
    wrap.appendChild(row);
  });
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
  });
}

/* =========================== BOOT =================================== */
document.addEventListener("DOMContentLoaded", function () {
  if (document.getElementById("modes")) initSettings();
  else if (document.getElementById("dots")) initOnboarding();
  else if (document.getElementById("live")) initPanel();
});
