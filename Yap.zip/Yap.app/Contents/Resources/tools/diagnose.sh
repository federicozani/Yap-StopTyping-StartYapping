#!/bin/bash
# Yap — "it doesn't work on this Mac" diagnostic.
#
# Run this ON THE MAC WHERE YAP MISBEHAVES:
#     bash diagnose.sh
#
# It only reads; it changes nothing. It prints the handful of things that
# actually stop Yap working on a second Mac, and the exact command to fix each.

echo "=============================================="
echo " Yap diagnostic"
echo "=============================================="
echo

echo "--- This Mac ---"
echo "macOS   : $(sw_vers -productVersion) ($(sw_vers -buildVersion))"
ARCH=$(uname -m)
echo "Processor: $ARCH"
if [ "$ARCH" != "arm64" ]; then
  echo "  *** PROBLEM: Yap is built for Apple Silicon and cannot run on this"
  echo "  *** Intel Mac. It will quit with a message at launch. You need a"
  echo "  *** build made on an Intel Mac."
fi
echo

echo "--- Copies of Yap on this Mac ---"
COPIES=$(mdfind -name "Yap.app" 2>/dev/null | grep -v "/dist/" )
[ -z "$COPIES" ] && COPIES=$(ls -d /Applications/Yap.app ~/Applications/Yap.app ~/Downloads/Yap.app ~/Desktop/Yap.app 2>/dev/null)
N=0
while IFS= read -r app; do
  [ -z "$app" ] && continue
  N=$((N+1))
  V=$(/usr/libexec/PlistBuddy -c "Print CFBundleShortVersionString" "$app/Contents/Info.plist" 2>/dev/null)
  echo "  [$N] $app   (version ${V:-unknown})"
done <<< "$COPIES"
if [ "$N" -gt 1 ]; then
  echo "  *** PROBLEM: more than one copy. Two copies fight over the keyboard"
  echo "  *** shortcut, and macOS grants permissions to only one of them."
  echo "  *** Fix: drag every copy but /Applications/Yap.app to the Trash,"
  echo "  ***      then empty it, then reboot."
fi
[ "$N" -eq 0 ] && echo "  (none found)"
echo

APP=/Applications/Yap.app
if [ ! -d "$APP" ]; then
  echo "*** Yap is not in /Applications. Move it there in Finder before granting"
  echo "*** permissions — macOS ties them to the app's location."
  exit 0
fi

echo "--- Is it still marked as downloaded? ---"
Q=$(xattr -p com.apple.quarantine "$APP" 2>/dev/null)
if [ -n "$Q" ]; then
  echo "  quarantine flag: $Q"
  echo "  *** PROBLEM: macOS may run a downloaded app from a hidden read-only"
  echo "  *** copy (App Translocation). Permissions can NEVER stick to it."
  echo "  *** Fix: xattr -dr com.apple.quarantine $APP"
else
  echo "  clean (no quarantine flag)"
fi
echo

echo "--- Signature ---"
codesign -dv "$APP" 2>&1 | grep -E "^Identifier|^TeamIdentifier" | sed 's/^/  /'
codesign -d -r- "$APP" 2>&1 | grep designated | sed 's/^/  /'
if codesign --verify --deep --strict "$APP" 2>/dev/null; then
  echo "  signature is intact"
else
  echo "  *** PROBLEM: the signature is broken — the app was modified or the"
  echo "  *** copy is incomplete. Copy Yap.app over again."
fi
echo

echo "--- Permissions macOS has recorded ---"
DB="$HOME/Library/Application Support/com.apple.TCC/TCC.db"
if [ -r "$DB" ]; then
  sqlite3 "$DB" "select service, auth_value from access where client='com.yap.app';" 2>/dev/null \
    | sed 's/^/  /' || echo "  (cannot read — Terminal needs Full Disk Access to see this)"
else
  echo "  (cannot read the permission database — that's normal)"
fi
echo "  Check by eye in System Settings > Privacy & Security:"
echo "    Microphone / Input Monitoring / Accessibility — Yap must be ON in all three."
echo
echo "  *** If a toggle is already ON but Yap still does nothing, macOS is holding"
echo "  *** a stale entry from the OLD copy. That is the usual cause. Fix:"
echo "  ***   tccutil reset Microphone com.yap.app"
echo "  ***   tccutil reset ListenEvent com.yap.app"
echo "  ***   tccutil reset Accessibility com.yap.app"
echo "  *** then reopen Yap and allow all three again when asked."
echo

echo "--- What Yap itself last reported ---"
if [ -f "$HOME/.yap/yap.log" ]; then
  tail -25 "$HOME/.yap/yap.log" | sed 's/^/  /'
else
  echo "  ~/.yap/yap.log does not exist — Yap has never started on this Mac."
  echo "  *** That points at a launch failure, not a permission problem."
fi
echo
echo "=============================================="
echo " Send the whole output above for a diagnosis."
echo "=============================================="
